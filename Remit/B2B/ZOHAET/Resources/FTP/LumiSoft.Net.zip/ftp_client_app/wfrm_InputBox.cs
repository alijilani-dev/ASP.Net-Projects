using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ftp_client_app
{
	/// <summary>
	/// Summary description for wfrm_InputBox.
	/// </summary>
	public class wfrm_InputBox : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox m_pText;
		private System.Windows.Forms.Button m_pOk;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public wfrm_InputBox()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		#region method Dispose

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.m_pText = new System.Windows.Forms.TextBox();
			this.m_pOk = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// m_pText
			// 
			this.m_pText.Location = new System.Drawing.Point(8, 16);
			this.m_pText.Name = "m_pText";
			this.m_pText.Size = new System.Drawing.Size(208, 20);
			this.m_pText.TabIndex = 0;
			this.m_pText.Text = "";
			// 
			// m_pOk
			// 
			this.m_pOk.Location = new System.Drawing.Point(232, 16);
			this.m_pOk.Name = "m_pOk";
			this.m_pOk.Size = new System.Drawing.Size(40, 24);
			this.m_pOk.TabIndex = 1;
			this.m_pOk.Text = "Ok";
			this.m_pOk.Click += new System.EventHandler(this.m_pOk_Click);
			// 
			// wfrm_InputBox
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 53);
			this.Controls.Add(this.m_pOk);
			this.Controls.Add(this.m_pText);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.Name = "wfrm_InputBox";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "wfrm_InputBox";
			this.ResumeLayout(false);

		}
		#endregion


		#region Events handling

		private void m_pOk_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
		}

		#endregion


		/// <summary>
		/// 
		/// </summary>
		public string wp_Text
		{
			get{ return m_pText.Text; }
		}

	}
}
