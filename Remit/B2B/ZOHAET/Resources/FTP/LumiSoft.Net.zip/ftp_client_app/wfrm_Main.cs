using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
//using LumiSoft.Net.FTP.Client;

namespace ftp_client_app
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class wfrm_Main : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.Button m_pGo;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ImageList imageList1;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem_Download;
		private System.Windows.Forms.MenuItem menuItem_Upload;
		private System.Windows.Forms.MenuItem menuItem_DeleteFile;
		private System.Windows.Forms.MenuItem menuItem_CreateDir;
		private System.Windows.Forms.MenuItem menuItem_DeleteDir;
		private System.Windows.Forms.TextBox m_pPassword;
		private System.Windows.Forms.TextBox m_pUserName;
		private System.Windows.Forms.TextBox m_pServer;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.MenuItem menuItem_RenameFile;
		private System.Windows.Forms.MenuItem menuItem_RenameDir;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.CheckBox m_pPassive;

		private FTP_Client m_pFtpClient = null;

		public wfrm_Main()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		#region method Dispose

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(m_pFtpClient != null){
				m_pFtpClient.Disconnect();
				m_pFtpClient = null;
			}

			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(wfrm_Main));
			this.listView1 = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.m_pGo = new System.Windows.Forms.Button();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.menuItem_Download = new System.Windows.Forms.MenuItem();
			this.menuItem_Upload = new System.Windows.Forms.MenuItem();
			this.menuItem_DeleteFile = new System.Windows.Forms.MenuItem();
			this.menuItem_RenameFile = new System.Windows.Forms.MenuItem();
			this.menuItem_CreateDir = new System.Windows.Forms.MenuItem();
			this.menuItem_DeleteDir = new System.Windows.Forms.MenuItem();
			this.menuItem_RenameDir = new System.Windows.Forms.MenuItem();
			this.m_pPassword = new System.Windows.Forms.TextBox();
			this.m_pUserName = new System.Windows.Forms.TextBox();
			this.m_pServer = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.m_pPassive = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// listView1
			// 
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader1,
																						this.columnHeader2,
																						this.columnHeader4});
			this.listView1.FullRowSelect = true;
			this.listView1.HideSelection = false;
			this.listView1.Location = new System.Drawing.Point(0, 88);
			this.listView1.MultiSelect = false;
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(632, 352);
			this.listView1.SmallImageList = this.imageList1;
			this.listView1.TabIndex = 0;
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.DoubleClick += new System.EventHandler(this.listView1_DoubleClick);
			this.listView1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseUp);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Name";
			this.columnHeader1.Width = 360;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Date";
			this.columnHeader2.Width = 140;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Size";
			this.columnHeader4.Width = 100;
			// 
			// imageList1
			// 
			this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// m_pGo
			// 
			this.m_pGo.Location = new System.Drawing.Point(496, 24);
			this.m_pGo.Name = "m_pGo";
			this.m_pGo.Size = new System.Drawing.Size(120, 24);
			this.m_pGo.TabIndex = 1;
			this.m_pGo.Text = "Connect";
			this.m_pGo.Click += new System.EventHandler(this.m_pGo_Click);
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem_Download,
																						 this.menuItem_Upload,
																						 this.menuItem_DeleteFile,
																						 this.menuItem_RenameFile,
																						 this.menuItem_CreateDir,
																						 this.menuItem_DeleteDir,
																						 this.menuItem_RenameDir});
			// 
			// menuItem_Download
			// 
			this.menuItem_Download.Index = 0;
			this.menuItem_Download.Text = "Download file";
			this.menuItem_Download.Click += new System.EventHandler(this.menuItem_Download_Click);
			// 
			// menuItem_Upload
			// 
			this.menuItem_Upload.Index = 1;
			this.menuItem_Upload.Text = "Upload file";
			this.menuItem_Upload.Click += new System.EventHandler(this.menuItem_Upload_Click);
			// 
			// menuItem_DeleteFile
			// 
			this.menuItem_DeleteFile.Index = 2;
			this.menuItem_DeleteFile.Text = "Delete file";
			this.menuItem_DeleteFile.Click += new System.EventHandler(this.menuItem_DeleteFile_Click);
			// 
			// menuItem_RenameFile
			// 
			this.menuItem_RenameFile.Index = 3;
			this.menuItem_RenameFile.Text = "Rename file";
			this.menuItem_RenameFile.Click += new System.EventHandler(this.menuItem_RenameFile_Click);
			// 
			// menuItem_CreateDir
			// 
			this.menuItem_CreateDir.Index = 4;
			this.menuItem_CreateDir.Text = "Create directory";
			this.menuItem_CreateDir.Click += new System.EventHandler(this.menuItem_CreateDir_Click);
			// 
			// menuItem_DeleteDir
			// 
			this.menuItem_DeleteDir.Index = 5;
			this.menuItem_DeleteDir.Text = "Delete directory";
			this.menuItem_DeleteDir.Click += new System.EventHandler(this.menuItem_DeleteDir_Click);
			// 
			// menuItem_RenameDir
			// 
			this.menuItem_RenameDir.Index = 6;
			this.menuItem_RenameDir.Text = "Rename directory";
			this.menuItem_RenameDir.Click += new System.EventHandler(this.menuItem_RenameDir_Click);
			// 
			// m_pPassword
			// 
			this.m_pPassword.Location = new System.Drawing.Point(336, 24);
			this.m_pPassword.Name = "m_pPassword";
			this.m_pPassword.Size = new System.Drawing.Size(112, 20);
			this.m_pPassword.TabIndex = 2;
			this.m_pPassword.Text = "";
			// 
			// m_pUserName
			// 
			this.m_pUserName.Location = new System.Drawing.Point(208, 24);
			this.m_pUserName.Name = "m_pUserName";
			this.m_pUserName.Size = new System.Drawing.Size(112, 20);
			this.m_pUserName.TabIndex = 3;
			this.m_pUserName.Text = "";
			// 
			// m_pServer
			// 
			this.m_pServer.Location = new System.Drawing.Point(40, 24);
			this.m_pServer.Name = "m_pServer";
			this.m_pServer.Size = new System.Drawing.Size(144, 20);
			this.m_pServer.TabIndex = 4;
			this.m_pServer.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(40, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(120, 16);
			this.label1.TabIndex = 5;
			this.label1.Text = "Server";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(208, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(120, 16);
			this.label2.TabIndex = 6;
			this.label2.Text = "User name";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(336, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(120, 16);
			this.label3.TabIndex = 7;
			this.label3.Text = "Password";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(0, 72);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(384, 16);
			this.label4.TabIndex = 8;
			this.label4.Text = "Right click to manage directories and files !";
			// 
			// m_pPassive
			// 
			this.m_pPassive.Checked = true;
			this.m_pPassive.CheckState = System.Windows.Forms.CheckState.Checked;
			this.m_pPassive.Location = new System.Drawing.Point(496, 56);
			this.m_pPassive.Name = "m_pPassive";
			this.m_pPassive.Size = new System.Drawing.Size(120, 16);
			this.m_pPassive.TabIndex = 9;
			this.m_pPassive.Text = "Passive";
			this.m_pPassive.CheckedChanged += new System.EventHandler(this.m_pPassive_CheckedChanged);
			// 
			// wfrm_Main
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(640, 469);
			this.Controls.Add(this.m_pPassive);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.m_pServer);
			this.Controls.Add(this.m_pUserName);
			this.Controls.Add(this.m_pPassword);
			this.Controls.Add(this.m_pGo);
			this.Controls.Add(this.listView1);
			this.Name = "wfrm_Main";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new wfrm_Main());
		}


		#region Events handling

		#region method m_pGo_Click

		private void m_pGo_Click(object sender, System.EventArgs e)
		{	
			try{
				if(m_pFtpClient == null){
					m_pGo.Text = "Disconnect";
					m_pFtpClient = new FTP_Client();
					//m_pFtpClient.Connect(m_pServer.Text,21);
					m_pFtpClient.Connect("ftp://65.223.147.201/",21);
					m_pFtpClient.Authenticate(m_pUserName.Text,m_pPassword.Text);
					m_pFtpClient.PassiveMode = m_pPassive.Checked;

					LoadDir("/");
				}
				else{
					m_pFtpClient.Disconnect();
					m_pFtpClient = null;

					m_pGo.Text = "Connect";

					// Clear list
					listView1.Items.Clear();
				}
			}			
			catch(Exception x ){
				MessageBox.Show(this,"Error:" + x.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}			
		}

		#endregion

		#region method listView1_DoubleClick

		private void listView1_DoubleClick(object sender, System.EventArgs e)
		{
			if(listView1.SelectedItems.Count == 0 || (bool)listView1.SelectedItems[0].Tag == false){
				return;
			}

			string dir = listView1.SelectedItems[0].Text;

			LoadDir(dir);
		}

		#endregion

		#region method listView1_MouseUp

		private void listView1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(e.Button != MouseButtons.Right || m_pFtpClient == null){
				return;
			}

			menuItem_Download.Visible   = false;
		//	menuItem_Upload.Visible     = false;
			menuItem_DeleteFile.Visible = false;
			menuItem_RenameFile.Visible = false;
		//	menuItem_CreateDir.Visible  = false;
			menuItem_DeleteDir.Visible  = false;
			menuItem_RenameDir.Visible  = false;

			if(listView1.SelectedItems.Count > 0 && listView1.SelectedItems[0].Text != ".."){
				if((bool)listView1.SelectedItems[0].Tag == false){
					menuItem_DeleteFile.Visible = true;
					menuItem_RenameFile.Visible = true;
					menuItem_Download.Visible   = true;
				}
				else{
					menuItem_DeleteDir.Visible  = true;
					menuItem_RenameDir.Visible  = true;
			    }
			}

			contextMenu1.Show(listView1,listView1.PointToClient(Control.MousePosition));
		}

		#endregion

		#region method menuItem_Download_Click

		private void menuItem_Download_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog dlg = new SaveFileDialog();
			dlg.RestoreDirectory = true;
			dlg.FileName = listView1.SelectedItems[0].Text;
			if(dlg.ShowDialog() == DialogResult.OK){
				using(FileStream fs = File.Create(dlg.FileName)){
					m_pFtpClient.ReceiveFile(listView1.SelectedItems[0].Text,fs);
				}
			}
		}

		#endregion

		#region method menuItem_Upload_Click

		private void menuItem_Upload_Click(object sender, System.EventArgs e)
		{
			try{
				OpenFileDialog dlg = new OpenFileDialog();
				dlg.RestoreDirectory = true;
				if(dlg.ShowDialog() == DialogResult.OK){
					m_pFtpClient.StoreFile(dlg.FileName);
					
					listView1.Items.Add(Path.GetFileName(dlg.FileName));
				}
			}			
			catch(Exception x ){
				MessageBox.Show(this,"Error:" + x.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
		}

		#endregion

		#region method menuItem_DeleteFile_Click

		private void menuItem_DeleteFile_Click(object sender, System.EventArgs e)
		{
			try{
				m_pFtpClient.DeleteFile(listView1.SelectedItems[0].Text);

				listView1.SelectedItems[0].Remove();
			}
			catch(Exception x ){
				MessageBox.Show(this,"Error:" + x.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
		}

		#endregion

		#region method menuItem_RenameFile_Click

		private void menuItem_RenameFile_Click(object sender, System.EventArgs e)
		{
			try{
				wfrm_InputBox dlg = new wfrm_InputBox();
				if(dlg.ShowDialog() == DialogResult.OK){
					m_pFtpClient.RenameFile(listView1.SelectedItems[0].Text,dlg.wp_Text);

					listView1.SelectedItems[0].Text = dlg.wp_Text;
				}
			}
			catch(Exception x ){
				MessageBox.Show(this,"Error:" + x.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
		}

		#endregion

		#region method menuItem_CreateDir_Click

		private void menuItem_CreateDir_Click(object sender, System.EventArgs e)
		{
			try{
				wfrm_InputBox dlg = new wfrm_InputBox();
				if(dlg.ShowDialog() == DialogResult.OK){
					m_pFtpClient.CreateDir(dlg.wp_Text);

					ListViewItem it = new ListViewItem(dlg.wp_Text);						
					it.Tag = true;
					it.ImageIndex = 0;
					listView1.Items.Add(it);
				}
			}
			catch(Exception x ){
				MessageBox.Show(this,"Error:" + x.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
		}

		#endregion

		#region method menuItem_DeleteDir_Click

		private void menuItem_DeleteDir_Click(object sender, System.EventArgs e)
		{
			try{
				m_pFtpClient.DeleteDir(listView1.SelectedItems[0].Text);

				listView1.SelectedItems[0].Remove();
			}
			catch(Exception x ){
				MessageBox.Show(this,"Error:" + x.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
		}

		#endregion

		#region method menuItem_RenameDir_Click

		private void menuItem_RenameDir_Click(object sender, System.EventArgs e)
		{
			try{
				wfrm_InputBox dlg = new wfrm_InputBox();
				if(dlg.ShowDialog() == DialogResult.OK){
					m_pFtpClient.RenameDir(listView1.SelectedItems[0].Text,dlg.wp_Text);

					listView1.SelectedItems[0].Text = dlg.wp_Text;
				}
			}
			catch(Exception x ){
				MessageBox.Show(this,"Error:" + x.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
		}

		#endregion

		#region method m_pPassive_CheckedChanged

		private void m_pPassive_CheckedChanged(object sender, System.EventArgs e)
		{
			if(m_pFtpClient != null){
				m_pFtpClient.PassiveMode = m_pPassive.Checked;
			}
		}

		#endregion

		#endregion
				
		#region method LoadDir

		private void LoadDir(string dir)
		{
			this.Cursor = Cursors.WaitCursor;
			
			try{
				m_pFtpClient.SetCurrentDir(dir);

				DataSet dsEntries = m_pFtpClient.GetList();

				// Clear list
				listView1.Items.Clear();

				ListViewItem itX = new ListViewItem("..");						
				itX.Tag = true;
				itX.ImageIndex = 2;
				listView1.Items.Add(itX);

				dsEntries.Tables["DirInfo"].DefaultView.Sort = "IsDirectory DESC,Name ASC";

				foreach(DataRowView drEnt in dsEntries.Tables["DirInfo"].DefaultView){
					ListViewItem it = new ListViewItem(drEnt["Name"].ToString());						
					it.Tag = Convert.ToBoolean(drEnt["IsDirectory"]);
					if(Convert.ToBoolean(drEnt["IsDirectory"])){
						it.ImageIndex = 0;
					}
					else{
						it.ImageIndex = 1;
					}
					it.SubItems.Add(Convert.ToDateTime(drEnt["Date"]).ToShortDateString());
					it.SubItems.Add(drEnt["Size"].ToString());
					listView1.Items.Add(it);
				}
			}
			catch(Exception x ){
				MessageBox.Show(this,"Error:" + x.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}

			this.Cursor = Cursors.Default;
		}

		#endregion

	}
}
