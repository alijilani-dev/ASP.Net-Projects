using System;

namespace ftp_client_app
{
	/// <summary>
	/// Summary description for FTP_FileSysEntry.
	/// </summary>
	public class FTP_FileSysEntry
	{
		private string   m_Name  = "";
		private DateTime m_Date;
		private bool     m_IsDir = false;
		private long     m_Size  = 0;

		/// <summary>
		/// Default constructor.
		/// </summary>
		/// <param name="name">Entry name.</param>
		/// <param name="date">Entry date.</param>
		/// <param name="isDir">Speciifes if entry is directory or file.</param>
		/// <param name="size">Specifies entry size.</param>
		public FTP_FileSysEntry(string name,DateTime date,bool isDir,long size)
		{
			m_Name  = name;
			m_Date  = date;
			m_IsDir = isDir;
			m_Size  = size;
		}


		#region Properties Implementation

		/// <summary>
		/// Gets entry name.
		/// </summary>
		public string Name
		{
			get{ return m_Name; }
		}

		/// <summary>
		/// Gets if entry is file.
		/// </summary>
		public bool IsFile
		{
			get{ return !m_IsDir; }
		}

		/// <summary>
		/// Gets if entry is directory.
		/// </summary>
		public bool IsDirectory
		{
			get{ return m_IsDir; }
		}

		/// <summary>
		/// Gets entry size. NOTE: Available only if entry is file.
		/// </summary>
		public long Size
		{
			get{ return m_Size; }
		}

		/// <summary>
		/// Gets entry date.
		/// </summary>
		public DateTime Date
		{
			get{ return m_Date; }
		}

		#endregion
	}
}
