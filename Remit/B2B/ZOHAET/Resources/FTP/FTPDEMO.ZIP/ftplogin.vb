Public Class FtpLogin
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents Label5 As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents txtPassword As System.Windows.Forms.TextBox
  Friend WithEvents txtServer As System.Windows.Forms.TextBox
  Friend WithEvents txtUser As System.Windows.Forms.TextBox
  Friend WithEvents cmdLogin As System.Windows.Forms.Button
  Friend WithEvents cmdCancel As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.cmdLogin = New System.Windows.Forms.Button()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.txtPassword = New System.Windows.Forms.TextBox()
    Me.txtServer = New System.Windows.Forms.TextBox()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.cmdCancel = New System.Windows.Forms.Button()
    Me.txtUser = New System.Windows.Forms.TextBox()
    Me.SuspendLayout()
    '
    'cmdLogin
    '
    Me.cmdLogin.Location = New System.Drawing.Point(48, 112)
    Me.cmdLogin.Name = "cmdLogin"
    Me.cmdLogin.Size = New System.Drawing.Size(64, 24)
    Me.cmdLogin.TabIndex = 5
    Me.cmdLogin.Text = "Login"
    '
    'Label5
    '
    Me.Label5.Location = New System.Drawing.Point(8, 74)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(56, 16)
    Me.Label5.TabIndex = 1
    Me.Label5.Text = "Password"
    '
    'txtPassword
    '
    Me.txtPassword.Location = New System.Drawing.Point(80, 72)
    Me.txtPassword.Name = "txtPassword"
    Me.txtPassword.PasswordChar = ChrW(42)
    Me.txtPassword.Size = New System.Drawing.Size(152, 20)
    Me.txtPassword.TabIndex = 2
    Me.txtPassword.Text = "Anonymous"
    '
    'txtServer
    '
    Me.txtServer.Location = New System.Drawing.Point(80, 8)
    Me.txtServer.Name = "txtServer"
    Me.txtServer.Size = New System.Drawing.Size(152, 20)
    Me.txtServer.TabIndex = 0
    Me.txtServer.Text = "ftp.microsoft.com"
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(8, 10)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(72, 16)
    Me.Label2.TabIndex = 1
    Me.Label2.Text = "Host Name"
    '
    'Label3
    '
    Me.Label3.Location = New System.Drawing.Point(8, 42)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(48, 16)
    Me.Label3.TabIndex = 1
    Me.Label3.Text = "User"
    '
    'cmdCancel
    '
    Me.cmdCancel.Location = New System.Drawing.Point(128, 112)
    Me.cmdCancel.Name = "cmdCancel"
    Me.cmdCancel.Size = New System.Drawing.Size(64, 24)
    Me.cmdCancel.TabIndex = 5
    Me.cmdCancel.Text = "Cancel"
    '
    'txtUser
    '
    Me.txtUser.Location = New System.Drawing.Point(80, 40)
    Me.txtUser.Name = "txtUser"
    Me.txtUser.Size = New System.Drawing.Size(152, 20)
    Me.txtUser.TabIndex = 1
    Me.txtUser.Text = "Anonymous"
    '
    'Login
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(240, 149)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label2, Me.Label5, Me.Label3, Me.txtPassword, Me.txtServer, Me.txtUser, Me.cmdLogin, Me.cmdCancel})
    Me.Name = "FtpLogin"
    Me.Text = "Login"
    Me.ResumeLayout(False)

  End Sub

#End Region
  Public blnLogin As Boolean = False

  Private Sub cmdLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLogin.Click
    blnLogin = True
    Me.Close()
  End Sub

  Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
    blnLogin = False
    Me.Close()
  End Sub
End Class
