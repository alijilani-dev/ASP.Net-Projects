You need NUnit 2.0 to run the tests. It is available at http://www.nunit.org/

See Sites.cs and Tests.cs on how to set up a testing environment.
