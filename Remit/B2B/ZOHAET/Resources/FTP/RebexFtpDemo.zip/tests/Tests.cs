using System;
using NUnit.Framework;

/*
 * This file defines tests to be seen and run by NUnit.
 * Customize it to suit your needs:
 * - add tests
 * - change sites
 * 
 */

namespace Rebex.Tests.FtpTest
{
	/*************** FtpBasicTest ***************/

	[TestFixture]
	public class LocalhostBasicTest: FtpBasicTest
	{
		public LocalhostBasicTest() {Site = new SiteLocalhost(); }
	}

	[TestFixture]
	public class MasloBasicTest: FtpBasicTest
	{
		public MasloBasicTest() {Site = new SiteMaslo(); }
	}	

	/*************** FtpStreamTest ***************/
	[TestFixture]
	public class LocalhostStreamTest: FtpStreamTest
	{
		public LocalhostStreamTest() {Site = new SiteLocalhost(); }
	}

	[TestFixture]
	public class MasloStreamTest: FtpStreamTest
	{
		public MasloStreamTest() {Site = new SiteMaslo(); }
	}

	/*************** FtpAsyncTest ***************/
	[TestFixture]
	public class LocalhostAsyncTest: FtpAsyncTest
	{
		public LocalhostAsyncTest() {Site = new SiteLocalhost(); }
	}

	[TestFixture]
	public class MasloAsyncTest: FtpAsyncTest
	{
		public MasloAsyncTest() {Site = new SiteMaslo(); }
	}

	/*************** FtpGetListTest ***************/
	[TestFixture]
	public class LocalhostFtpGetListTest: FtpGetListTest
	{
		public LocalhostFtpGetListTest() {Site = new SiteLocalhost(); }
	}
	
	[TestFixture]
	public class MasloFtpGetListTest: FtpGetListTest
	{
		public MasloFtpGetListTest() {Site = new SiteMaslo(); }
	}

	/*************** FtpWebRequestTest ***************/
	[TestFixture]
	public class LocalhostFtpWebRequestTest: FtpWebRequestTest
	{
		public LocalhostFtpWebRequestTest() {Site = new SiteLocalhost(); }
	}

	[TestFixture]
	public class MasloFtpWebRequestTest: FtpWebRequestTest
	{
		public MasloFtpWebRequestTest() {Site = new SiteMaslo(); }
	}
	
}