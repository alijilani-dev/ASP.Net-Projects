using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Rebex FTP.NET NUnit Tests")]
[assembly: AssemblyDescription("Tests for Rebex FTP client component for .NET")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Rebex")]
[assembly: AssemblyProduct("Rebex FTP.NET")]
[assembly: AssemblyCopyright("Copyright (c) 2002-2003 Rebex")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
