using System;
using System.Net;
using NUnit.Framework;

namespace Rebex.Tests.FtpTest
{
	public class SiteKarma : Site
	{
		public SiteKarma ()
		{
			Host      = "karma";
			Port      = 21;
			Login     = "tester";
			Password  = "tester";
			UploadDir = "/home/tester";
			NoModifyDir = "/usr";
		}
	}

	public class SiteKralik : Site
	{
		public SiteKralik ()
		{
			Host      = "kralik";
			Port      = 21;
			Login     = "anonymous";
			Password  = "test";
			UploadDir = "/incoming";
			NoModifyDir = "/shared";
		}
	}

	public class SiteKarma2 : Site
	{
		public SiteKarma2 ()
		{
			Host      = "karma";
			Port      = 2121;
			Login     = "shakul";
			Password  = "bambus1";
			UploadDir = "/incoming";
			NoModifyDir = "/apps";
		}
	}


	public class SiteScene : Site
	{
		public SiteScene ()
		{
			Host      = "avalcon.scene.cz";
			Port      = 21;
			Login     = "fshakul";
			Password  = "xsih8R";
			UploadDir = "/home/shakul";
			NoModifyDir = "/usr";
		}
	}
}
