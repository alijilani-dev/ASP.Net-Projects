using System;
using NUnit.Framework;

namespace Rebex.Tests.FtpTest
{
	using System;
	using NUnit.Framework;

	/*************** FtpBasicTest ***************/

	[TestFixture]
	public class KralikBasicTest: FtpBasicTest
	{
		public KralikBasicTest() {Site = new SiteKralik(); }
	}

	[TestFixture]
	public class KarmaBasicTest: FtpBasicTest
	{
		public KarmaBasicTest() {Site = new SiteKarma(); }
	}	

	[TestFixture]
	public class Karma2BasicTest: FtpBasicTest
	{
		public Karma2BasicTest() {Site = new SiteKarma2(); }
	}	

	[TestFixture]
	public class SceneBasicTest: FtpBasicTest
	{
		public SceneBasicTest() {Site = new SiteScene(); }
	}	

	[TestFixture]
	public class KralikStreamTest: FtpStreamTest
	{
		public KralikStreamTest() {Site = new SiteKralik(); }
	}

	[TestFixture]
	public class KarmaStreamTest: FtpStreamTest
	{
		public KarmaStreamTest() {Site = new SiteKarma(); }
	}

	[TestFixture]
	public class Karma2StreamTest: FtpStreamTest
	{
		public Karma2StreamTest() {Site = new SiteKarma2(); }
	}

	[TestFixture]
	public class SceneStreamTest: FtpStreamTest
	{
		public SceneStreamTest() {Site = new SiteScene(); }
	}

	[TestFixture]
	public class KarmaAsyncTest: FtpAsyncTest
	{
		public KarmaAsyncTest() {Site = new SiteKarma(); }
	}

	[TestFixture]
	public class Karma2AsyncTest: FtpAsyncTest
	{
		public Karma2AsyncTest() {Site = new SiteKarma2(); }
	}

	[TestFixture]
	public class SceneAsyncTest: FtpAsyncTest
	{
		public SceneAsyncTest() {Site = new SiteScene(); }
	}

	/*************** FtpGetListTest ***************/
	
	[TestFixture]
	public class KarmaFtpGetListTest: FtpGetListTest
	{
		public KarmaFtpGetListTest() {Site = new SiteKarma(); }
	}

	[TestFixture]
	public class Karma2FtpGetListTest: FtpGetListTest
	{
		public Karma2FtpGetListTest() {Site = new SiteKarma2(); }
	}

	[TestFixture]
	public class KralikFtpGetListTest: FtpGetListTest
	{
		public KralikFtpGetListTest() {Site = new SiteKralik(); }
	}

	[TestFixture]
	public class SceneFtpGetListTest: FtpGetListTest
	{
		public SceneFtpGetListTest() {Site = new SiteScene(); }
	}

	/*************** FtpWebRequestTest ***************/

	[TestFixture]
	public class KralikFtpWebRequestTest: FtpWebRequestTest
	{
		public KralikFtpWebRequestTest() {Site = new SiteKralik(); }
	}

	[TestFixture]
	public class KarmaFtpWebRequestTest: FtpWebRequestTest
	{
		public KarmaFtpWebRequestTest() {Site = new SiteKarma(); }
	}

	[TestFixture]
	public class Karma2FtpWebRequestTest: FtpWebRequestTest
	{
		public Karma2FtpWebRequestTest() {Site = new SiteKarma2(); }
	}

	[TestFixture]
	public class SceneFtpWebRequestTest: FtpWebRequestTest
	{
		public SceneFtpWebRequestTest() {Site = new SiteScene(); }
	}
	

	/*************** FtpBasicTest ***************/

	[TestFixture]
	public class LocalhostFtpInternalTest: FtpInternalTest
	{
		public LocalhostFtpInternalTest() {Site = new SiteLocalhost(); }
	}

	[TestFixture]
	public class KarmaFtpInternalTest: FtpInternalTest
	{
		public KarmaFtpInternalTest() {Site = new SiteKarma(); }
	}

	[TestFixture]
	public class SceneFtpInternalTest: FtpInternalTest
	{
		public SceneFtpInternalTest() {Site = new SiteScene(); }
	}

	[TestFixture]
	public class KralikFtpInternalTest: FtpInternalTest
	{
		public KralikFtpInternalTest() {Site = new SiteKralik(); }
	}
		
	[TestFixture]
	public class Karma2FtpInternalTest: FtpInternalTest
	{
		public Karma2FtpInternalTest() {Site = new SiteKarma2(); }
	}
	
	[TestFixture]
	public class MasloFtpInternalTest: FtpInternalTest
	{
		public MasloFtpInternalTest() {Site = new SiteMaslo(); }
	}
}

