
namespace DataGridTextBoxCombo
{
	using System;
	using System.Drawing;
	using System.Collections;
	using System.ComponentModel;
	using System.Windows.Forms;
	using System.Data;
	using System.Data.OleDb;

	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;
		private DataSet myDataSet;
		OleDbDataAdapter dataAdapter;
		private System.Windows.Forms.DataGrid dataGrid2;
		private System.Windows.Forms.DataGrid dataGrid3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			MakeDataSetAndBindGrid();
		}

		

		private void MakeDataSetAndBindGrid()
		{
			// Set the connection and sql strings
			// assumes your mdb file is in your root
			string connString = @"Provider=Microsoft.JET.OLEDB.4.0;data source=C:\nwind.mdb";
			string sqlString = "SELECT * FROM orders";

			dataAdapter = null;
			myDataSet = null;

			try
			{
				// Connection object
				OleDbConnection connection = new OleDbConnection(connString);

				// Create data adapter object
				dataAdapter = new OleDbDataAdapter(sqlString, connection);
			
				// Create a dataset object and fill with data using data adapter's Fill method
				myDataSet = new DataSet();
				dataAdapter.Fill(myDataSet, "orders");


				//now load the datatable for the bound combobox...
				//notice that the combobox & grid are NOT  bound to the same
				//table (if bound to the same table, you must have different binding contexts)
				sqlString = "SELECT customerID, contactName FROM customers";//use for string value in combo
				
				//use as sample for integer value in combo 
				//sqlString = "SELECT employeeId, lastName FROM employees";//use for integer value in combo

				dataAdapter = new OleDbDataAdapter(sqlString, connection);
				dataAdapter.Fill(myDataSet, "customerList");

			

				connection.Close();
			}
			catch(Exception ex)
			{	
				MessageBox.Show("Problem with DB access-\n\n   connection: "
					+ connString + "\r\n\r\n            query: " + sqlString
					+ "\r\n\r\n\r\n" + ex.ToString());
				this.Close();
				return;
			}

			// Create a table style that will hold the new column style 
			// that we set and also tie it to our customer's table from our DB
			DataGridTableStyle tableStyle = new DataGridTableStyle();
			tableStyle.MappingName = "orders";

			DataTable dt = myDataSet.Tables["orders"];
				
			// make the dataGrid use our new tablestyle and bind it to our table
			for(int i = 0; i < dt.Columns.Count; ++i)
			{
				//if(i != 2) //use for integer value in combo
				if(i != 1)
				{
					DataGridTextBoxColumn TextCol = new DataGridTextBoxColumn();
					TextCol.MappingName = dt.Columns[i].ColumnName;
					TextCol.HeaderText = dt.Columns[i].ColumnName;
					tableStyle.GridColumnStyles.Add(TextCol);
					
				}
				else
				{
						//now created a formated column using the pdc
					
					DataGridComboBoxColumn ComboTextCol = new DataGridComboBoxColumn();

					//use as sample for integer value in combo 
					//ComboTextCol.MappingName = "employeeID"; //must be from the grid table...
					ComboTextCol.MappingName = "customerID"; //must be from the grid table...
					
					ComboTextCol.HeaderText = "ComboColumn";
					ComboTextCol.Width = 120;
					//DataView dv = new DataView(myDataSet.Tables["customerList"], "", "customerID", DataViewRowState.CurrentRows);
					ComboTextCol.ColumnComboBox.DataSource = myDataSet.Tables["customerList"].DefaultView;//dv;
					//ComboTextCol.ColumnComboBox.DisplayMember = "lastName";//use for integer value in combo
					//ComboTextCol.ColumnComboBox.ValueMember = "employeeID";//use for integer value in combo
					ComboTextCol.ColumnComboBox.DisplayMember = "contactName";//use for string value in combo
					ComboTextCol.ColumnComboBox.ValueMember = "customerID";//use for string value in combo

					
					tableStyle.PreferredRowHeight = ComboTextCol.ColumnComboBox.Height + 2;
		
					tableStyle.GridColumnStyles.Add(ComboTextCol);
				}
			}
			
			dataGrid1.TableStyles.Clear();
			dataGrid1.TableStyles.Add(tableStyle);
			dataGrid1.DataSource = dt;

			//in datagrid2, you can see the raw table without the combobox.
			// As you change the combo displaymember in grid1, 
			// the valuemember in grid2 should change as you move off the row...
			dataGrid2.DataSource = dt;

			//let datagrid3 display the combobox table
			dataGrid3.PreferredColumnWidth = 97;
			dataGrid3.DataSource = myDataSet.Tables["customerList"].DefaultView;
			dataGrid3.Enabled = false;// for display only - no clicking...

			//make it no append/edit
			myDataSet.Tables["customerList"].DefaultView.AllowDelete = false;
			myDataSet.Tables["customerList"].DefaultView.AllowNew = false;
			myDataSet.Tables["customerList"].DefaultView.AllowEdit = false;

		}




		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.dataGrid2 = new System.Windows.Forms.DataGrid();
			this.dataGrid3 = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid3)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGrid1
			// 
			this.dataGrid1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.dataGrid1.CaptionText = "DataGrid1 with ComboBox in column 1 showing DisplayMember";
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(16, 24);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(624, 200);
			this.dataGrid1.TabIndex = 0;
			// 
			// dataGrid2
			// 
			this.dataGrid2.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.dataGrid2.CaptionText = "DataGrid 2 shows ValueMember in column 1";
			this.dataGrid2.DataMember = "";
			this.dataGrid2.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid2.Location = new System.Drawing.Point(16, 248);
			this.dataGrid2.Name = "dataGrid2";
			this.dataGrid2.Size = new System.Drawing.Size(368, 112);
			this.dataGrid2.TabIndex = 1;
			// 
			// dataGrid3
			// 
			this.dataGrid3.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.dataGrid3.CaptionText = "DataGrid3 combobox values";
			this.dataGrid3.DataMember = "";
			this.dataGrid3.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid3.Location = new System.Drawing.Point(392, 248);
			this.dataGrid3.Name = "dataGrid3";
			this.dataGrid3.Size = new System.Drawing.Size(248, 112);
			this.dataGrid3.TabIndex = 2;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(656, 373);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dataGrid3,
																		  this.dataGrid2,
																		  this.dataGrid1});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid3)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		public static void Main() 
		{
			Application.Run(new Form1());
		}
		
	}

	// Step 1. Derive a custom column style from DataGridTextBoxColumn
	//	a) add a ComboBox member
	//  b) track when the combobox has focus in Enter and Leave events
	//  c) override Edit to allow the ComboBox to replace the TextBox
	//  d) override Commit to save the changed data
	public class DataGridComboBoxColumn : DataGridTextBoxColumn
	{
		public NoKeyUpCombo ColumnComboBox;
		private System.Windows.Forms.CurrencyManager _source;
		private int _rowNum;
		private bool _isEditing;
		public static int _RowCount;
		
		public DataGridComboBoxColumn() : base()
		{
			_source = null;
			_isEditing = false;
			_RowCount = -1;
	
			ColumnComboBox = new NoKeyUpCombo();
			ColumnComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
		
			ColumnComboBox.Leave += new EventHandler(LeaveComboBox);
	//		ColumnComboBox.Enter += new EventHandler(ComboMadeCurrent);
			ColumnComboBox.SelectionChangeCommitted += new EventHandler(ComboStartEditing);
		
		}
		private void ComboStartEditing(object sender, EventArgs e)
		{
			_isEditing = true;
 		   base.ColumnStartedEditing((Control) sender);
		}

		private void HandleScroll(object sender, EventArgs e)
		{
			if(ColumnComboBox.Visible)
				ColumnComboBox.Hide();

		}
//		private void ComboMadeCurrent(object sender, EventArgs e)
//		{
//			_isEditing = true; 	
//		}
//		
		private void LeaveComboBox(object sender, EventArgs e)
		{
			if(_isEditing)
			{
				SetColumnValueAtRow(_source, _rowNum, ColumnComboBox.Text);
				_isEditing = false;
				Invalidate();
			}
			ColumnComboBox.Hide();
			this.DataGridTableStyle.DataGrid.Scroll -= new EventHandler(HandleScroll);
			
		}

		protected override void Edit(System.Windows.Forms.CurrencyManager source, int rowNum, System.Drawing.Rectangle bounds, bool readOnly, string instantText, bool cellIsVisible)
		{
			

			base.Edit(source,rowNum, bounds, readOnly, instantText , cellIsVisible);

			_rowNum = rowNum;
			_source = source;
		
			ColumnComboBox.Parent = this.TextBox.Parent;
			ColumnComboBox.Location = this.TextBox.Location;
			ColumnComboBox.Size = new Size(this.TextBox.Size.Width, ColumnComboBox.Size.Height);
			ColumnComboBox.SelectedIndex = ColumnComboBox.FindStringExact(this.TextBox.Text);
			ColumnComboBox.Text =  this.TextBox.Text;
			this.TextBox.Visible = false;
			ColumnComboBox.Visible = true;
			this.DataGridTableStyle.DataGrid.Scroll += new EventHandler(HandleScroll);
			
			ColumnComboBox.BringToFront();
			ColumnComboBox.Focus();	
		}

		protected override bool Commit(System.Windows.Forms.CurrencyManager dataSource, int rowNum)
		{
		
			if(_isEditing)
			{
				_isEditing = false;
				SetColumnValueAtRow(dataSource, rowNum, ColumnComboBox.Text);
			}
			return true;
		}

		protected override void ConcedeFocus()
		{
			Console.WriteLine("ConcedeFocus");
			base.ConcedeFocus();
		}

		protected override object GetColumnValueAtRow(System.Windows.Forms.CurrencyManager source, int rowNum)
		{

			object s =  base.GetColumnValueAtRow(source, rowNum);
			DataView dv = (DataView)this.ColumnComboBox.DataSource;
			int rowCount = dv.Count;
			int i = 0;

			//if things are slow, you could order your dataview
			//& use binary search instead of this linear one
			while (i < rowCount)
			{
				if( s.Equals( dv[i][this.ColumnComboBox.ValueMember]))
					break;
				++i;
			}
			
			if(i < rowCount)
				return dv[i][this.ColumnComboBox.DisplayMember];
			
			return DBNull.Value;
		}

		protected override void SetColumnValueAtRow(System.Windows.Forms.CurrencyManager source, int rowNum, object value)
		{
			object s = value;

			DataView dv = (DataView)this.ColumnComboBox.DataSource;
			int rowCount = dv.Count;
			int i = 0;

			//if things are slow, you could order your dataview
			//& use binary search instead of this linear one
			while (i < rowCount)
			{
				if( s.Equals( dv[i][this.ColumnComboBox.DisplayMember]))
					break;
				++i;
			}
			if(i < rowCount)
				s =  dv[i][this.ColumnComboBox.ValueMember];
			else
				s = DBNull.Value;
			base.SetColumnValueAtRow(source, rowNum, s);

		}
	
	}

	public class NoKeyUpCombo : ComboBox
	{
		private const int WM_KEYUP = 0x101;

		protected override void WndProc(ref System.Windows.Forms.Message m)
		{
			if(m.Msg == WM_KEYUP)
			{
				//ignore keyup to avoid problem with tabbing & dropdownlist;
				return;
			}
			base.WndProc(ref m);
		}
	}
}
